module.exports = {
    facebook: {
        login: ''
      , password: ''
    }
  , twitter: {
        login: ''
      , password: ''
    }
};
